
see:
  hfloat.lsm       (short description)
  doc/whatfor.txt  (what hfloat might be good for)
  doc/hfdoc.*      (documentation)
  00legal.txt      (legal notice)
