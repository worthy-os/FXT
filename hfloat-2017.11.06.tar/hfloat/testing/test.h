#if !defined HAVE_TEST_H__
#define      HAVE_TEST_H__


void do_test(long n, int arg2);
void test_usage(const char *argv0);

int test0(long n);
int test1(long n);
int test2(long n);
int test3(long n);
int test4(long n);
int test5(long n);
int test6(long n);
int test7(long n);


#endif // !defined HAVE_TEST_H__
