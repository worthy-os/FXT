#if !defined HAVE_MYTIMER_H__
#define      HAVE_MYTIMER_H__

void start_timer();
double return_elapsed_time();

#endif // !defined HAVE_MYTIMER_H__
