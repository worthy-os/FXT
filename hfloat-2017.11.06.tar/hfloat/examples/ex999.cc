//
// well, ... *semi* simple example 999:
// compute n**(n**n)
//

#include "hfloat.h"
#include "hfverbosity.h"
#include "fxtmult.h"

#include <fxt/fxtio.h>

#include <cmath>
#include <cstdlib>  // atol()
#include <unistd.h>  // unlink()
#include <iostream>


#define  XI(z)  \
 setw(8) << z.exp() << " [" << setw(2) << ceil(log(double(z.exp()))/log(2.0)) << "]"


#define HFPOW_USE_L2R  // whether to use left-to-right exponentiation
#ifdef HFPOW_USE_L2R
#include <bits/bithigh.h>  // highest_one()
#endif


int
main(int argc, char **argv)
{
    int poutq = 1; // whether to print result of mult/sqr
    ulong pp = 8;  // print prec. for above (in LIMBs)

    ulong n = 7;
    if ( argc>1 )  n = atol(argv[1]);

    ulong x = 1;
    for (ulong i=0; i<n; ++i)  x *= n;

    cout << "n = " << n << endl;
    cout << " ... computing  n**(n**n) = "  << n  << " ** " << x << endl;
    cout << endl;

    hfloat::radix(1000);

    ulong prec = (ulong)ceil( prec_convert(x, hfloat::radix(), n) );
    hfloat::default_prec(prec);
    hfverbosity::tell_all();
    hfverbosity::tell_fxtmult();
    hfloat::print_info();

#ifdef HFPOW_USE_L2R

    hfloat a(1), c, t;
    a.prec(1);
    c.prec(1);
    t.prec(1);
    a = n;

    c = a;
    ulong b = highest_one(x);
    while ( b>1 )
    {
        b >>= 1;

        t.prec( c.prec() + c.prec() );
        cout << XI(c) << "                 -- ";
        sqr(c, t);  // t *= t;  SQR
        t.prec( t.exp() );
        cout << " -->  " << XI(t) << endl;
        if ( poutq )  print("t*t==", t, pp);

        if ( x & b )
        {
            t.prec( a.prec() + t.prec() );
            cout << XI(a) << ", " << XI(t) << "  -- ";
            mul(t, a, t);  // t *= a;  MULT
            t.prec( t.exp() );
            cout << " -->  " << XI(t) << endl;
            if ( poutq )  print("a*c==", c, pp);
        }

        c.prec( t.prec() );
        c = t;
    }


#else // def HFPOW_USE_L2R

    hfloat a, c, t;
    a.prec(1);
    c.prec(1);
    t.prec(1);
    a = n;

    c = 1;
    int firstq = 1;
    while ( 1 )
    {
        if ( x&1 )  // odd
        {

            t.prec( a.prec() + c.prec() );
            cout << XI(c) << ", " << XI(a) << "  -- ";

            if ( firstq ) // avoid multiplication by 1
            {
                cout << " == ";
                t = a;
                firstq = 0;
            }
            else
            {
                mul(c, a, t);   // MULT
            }

            cout << " -->  " << XI(t) << endl;

            c.prec( t.exp() );
            c.copy( t );
            if ( poutq )  print("a*c==", c, pp);

            if ( x==1 )  break;
        }


        t.prec( a.prec() + a.prec() );

        cout << XI(a) << "                 -- ";
        sqr(a, t);   // SQR
        cout << " -->  " << XI(t) << endl;

        a.prec( t.exp() );
        a.copy( t );
        if ( poutq ) print("a*a==", t, pp);

        x /= 2;
    }
#endif // def HFPOW_USE_L2R


    cout << "\n computation finished." << endl;
    print("n**(n**n)==\n",c,16);
    cout << endl << " prec=" << c.prec() << " LIMBs "
         << " == " << prec_convert(c.prec(),10) << " dec.dig. " << endl;
    cout << endl;

    const char *fname = "/tmp/result.txt";
    cout << "saving result to file \"" << fname << "\" ... ";
    save(fname, c);
    cout << "done." << endl;

    hfloat::print_info();
    hfdata::print_statistics(prec);
    fxtmult::print_statistics(prec);

    return 0;
}
//---------------

// n = 7
// ... computing  n**(n**n) = 7 ** 823543
// hfdata: bytes currently allocated: 1391952
// hfdata: max bytes allocated: 1391952 (plus workspace)
// fxtmult: work was=3.02741 times length 2^20 real FFTs
// fxtmult: == 7.26931 full prec real FFTs
//./examples/ex999 7  1.85s user 0.01s system 92% cpu 2.000 total
//
// Same with L2R:
// hfdata: bytes currently allocated: 927972
// hfdata: max bytes allocated: 927972 (plus workspace)
// fxtmult: work was=0.849939 times length 2^20 real FFTs
// fxtmult: == 2.04084 full prec real FFTs
//./examples/ex999 7  0.59s user 0.01s system 90% cpu 0.664 total


//n = 8 // no gain because 8^8 is a power of two!
// ... computing  n**(n**n) = 8 ** 16777216
//n**(n**n)==
//+.6014520753651392037904506848876412035652344497*10^15151336
// prec=5050446 LIMBs  == 1.51513e+07 dec.dig.
//./examples/ex999 8  21.29s user 0.14s system 99% cpu 21.491 total
//
// Same with L2R:
// SSSSSSSS.S.S.S.S.S.S.S.S:S:S:S:S:S:S:S:S:
//n**(n**n)==
//+.6014520753651392037904506848876412035652344497*10^15151336
// prec=5050446 LIMBs  == 1.51513e+07 dec.dig.
//./examples/ex999 8  21.18s user 0.13s system 97% cpu 21.840 total
