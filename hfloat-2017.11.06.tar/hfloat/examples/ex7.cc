//
// simple example 7:
// means
//


#include "hfloat.h"
#include "hfverbosity.h"

#include <iostream>


int
main()
{
    hfverbosity::tell_mean();

    // precision in LIMBs, use a power of two:
    hfloat::default_prec(32);

    // radix, use 10000 (decimal) or 65536 (hex numbers):
    hfloat::radix(10000);

    hfloat a, b, c;

    a = 1;
    isqrt(2,b);  // b = 1/sqrt(2)
    print("a=\n",a,16);
    print("b=\n",b,16);
    agm(a,b,c);
    print("agm(a,b)=\n",c,0);
    // agm(1,1/sqrt(2)) = 0.847213084793979086606499123482191

    a = 0;
    b = 1;
    print("a=\n",a,16);
    print("b=\n",b,16);
    j_mean(a,b,c);
    print("j_mean(a,b)=\n",c,0);
    // j_mean(0,1) = 0.60797090857358476979336439617599719111

    return 0;
}
//---------------

/*
  a = 1; a/=3;
  b = 1; b/=7;
  print(" a=\n",a,8);
  print(" b=\n",b,8);
  mul(a,b,c);
  print(" a*b=\n",c,8);

  a = 10; a/=3;
  b = 1; b/=7;
  print(" a=\n",a,8);
  print(" b=\n",b,8);
  mul(a,b,c);
  print(" a*b=\n",c,8);

  return 999;
  */
