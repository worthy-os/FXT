//
// simple example 6:
// zeta(3)
//


#include "hfloat.h"

#include <iostream>


int main()
{
    // precision in LIMBs, use a power of two <= 1024:
    hfloat::default_prec(1024);

    // radix, use 10000 (decimal) or 65536 (hex numbers):
    hfloat::radix(10000);

    hfloat s;
    cout << " decimal precision=" << prec_convert(s.prec(),10) << endl;

    int k = zeta3(s);
    print("\n zeta3=\n",s);
    cout << "\n  " << k << " terms were added " << endl;

    return 0;
}
//---------------
