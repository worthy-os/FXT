//
// simple example 9:
// some constants printed in the pi-book
//


#include "hfloat.h"
#include "hfverbosity.h"

#include <fxt/jjassert.h>

#include <iostream>


void misc(ulong p);

int main()
{
    hfverbosity::hush_all();
//    hfverbosity::tell_all();

//    set_fail_action( JJ_ASSERT_STOP );

    hfloat::default_prec(128);
//    hfloat::default_prec(2048);

    hfloat::radix(10000);
    misc(25+1);

    hfloat::radix(65536);
//    hfloat::default_prec(4096);
    misc(25+1);

    return 0;
}
//---------------

static void
check(const hfloat &a, const hfloat &b)
{
//    ulong d;
//    cmp(a, b, d);  // fails with 0.9999 vs. 1.000
//    d = a.prec() - d;

    hfloat dd(a);  dd-=b;
    long d = -dd.exp();
    d = a.prec() - d;
//    cout << ":: check(): d=" << d << endl;
    if ( d>=10 )
        cout << "check(): the last " << d
             << " LIMBs (of total " << a.prec()
             << ") are incorrect " << endl;
    jjassert( d<15 );
}
//---------------

void
misc(ulong p)
//
// print with precision p
//
{
    hfloat t;
    hfloat pi;
    hfloat e;
    hfloat i(64);
    hfloat tt;  // for checking

    cout << "\n pi =";  cout.flush();
    pi_4th_order(pi);
    print( "\n", pi, p);


    cout << "\n pi^2 =";  cout.flush();
    sqr(pi,t);
    print("\n", t, p);


    cout << "\n pi^3 =";  cout.flush();
    pow(pi,3,t);
    print("\n", t, p);


    cout << "\n pi^4 =";  cout.flush();
    pow(pi,4,t);
    print("\n", t, p);


    cout << "\n pi^(1/2) =";  cout.flush();
    sqrt(pi,t);
    print("\n", t, p);


    cout << "\n pi^(1/3) =";  cout.flush();
    cbrt(pi,t);
    print("\n", t, p);
//    root(pi,3,t);
//    print("\n", t, p);

    cout << "\n pi^(1/4) =";  cout.flush();
    root(pi,4,t);
    print("\n", t, p);

    cout << "\n e =";  cout.flush();
    e = 1;
    exp(e,e);
    print( "\n", e, p);
    // check:
    log(e,tt);  // 1
//    print("\n :: log(e,tt) = ", tt, p);
    t = 1;
    check(t,tt);

    cout << "\n e^pi =";  cout.flush();
    exp(pi,t);
    print("\n", t, p);
    // check:
    log(t,t);    // pi
    check(pi,t);


    cout << "\n pi^e =";  cout.flush();
    pow(pi,e,t);
    print("\n", t, p);
    // check:
    log(t,pi,tt); // e
//    print("\n :: log(t,pi,tt) = ", tt, p);
//    log(t, tt);
//    print("\n :: log(t,tt) = ", tt, p);
//    log(pi, t);
//    print("\n :: log(pi,t) = ", tt, p);
//    tt /= t;
//    print("\n :: log(t,tt)/log(pi,t) = ", tt, p);
//    print("\n :: e = ", e, p);
    check(e,tt);

    cout << "\n e^(pi/4) =";  cout.flush();
    exp(pi/4,t);
    print("\n", t, p);


    cout << "\n ln(pi) =";  cout.flush();
    log(pi,t);
    print("\n", t, p);


    cout << "\n log_2(pi) =";  cout.flush();
    i = 2;
    log(pi,i,t);
    print("\n", t, p);


    cout << "\n log_10(pi) =";  cout.flush();
    i = 10;
    log(pi,i,t);
    print("\n", t, p);


    cout << "\n exp(sqrt(163)*pi) =";  cout.flush();
    sqrt(163,t);
    t *= pi;
    exp(t,t);
    print("\n", t, p);

    cout << "\n exp(sqrt(163)/3*pi) =";  cout.flush();
    cbrt(t,t);
    print("\n", t, p);
}
//---------------

