//
// simple example 10:
// alternating sums
//


#include "hfloat.h"
#include "hfverbosity.h"

#include <iostream>
#include <cstdlib>


int main(int argc, char **argv)
{
    // precision in LIMBs, use a power of two <= 1024:
    hfloat::default_prec(256);
    if ( argc>1 )  hfloat::default_prec( atol(argv[1]) );

    // radix, use 10000 (decimal) or 65536 (hex numbers):
    hfloat::radix(10000);


    hfloat s;
    cout << " decimal precision = " << prec_convert(s.prec(),10) << endl;

    // ------ compute pi:
    sumalt(gregory_term, s);  // compute pi as arctan(1)
    s *= 4;
    cout << "pi = " << s << endl;

    // ------ check pi:
    cout << " checking value:" << endl;
    hfverbosity::hush_all();
    hfloat p = hfloat();
    p = constant_pi(p.prec());  // pi_4th_order(p);
    s -= p;
    print(" difference = ",s,3);
    cout << endl;


    // compute catalan=0.91596559417721901505...:
    sumalt(catalan_term, s);
    cout << "\n catalan = " << s << endl;

    // compute log(2) = 0.6931471805599453094...:
    sumalt(log2_term, s);
    cout << "\n log(2) = " << s << endl;

    cout << endl;

    return 0;
}
//---------------
