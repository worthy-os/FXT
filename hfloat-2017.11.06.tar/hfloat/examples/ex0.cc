//
// simple example 0:
// addition, multiplication
//

#include "hfloat.h"

//#define TIMING // define to disable printing

int main()
{
#ifdef TIMING
    hfloat::default_prec(1UL<<20);
#else
    // precision in LIMBs, use a power of two:
    hfloat::default_prec(64);
#endif

    // radix, use 10000 (decimal) or 65536 (hex numbers):
    hfloat::radix(10000);

    hfloat a;
    hfloat b;
    hfloat c;
    b = 999;
    a = "1.000000000000000000000000000000000000000777e-6";

#ifdef TIMING
    mul(a,b,c);
#else
    print("\n a= \n",a);
    print("\n b= \n",b);

    add(a,b,c);    // func(src1,src2,dest);
    print("\n a+b= \n",c);

    a = ".90005e1177";
    b = "  3.14000000e23456  ";
    print("\n a= \n",a);
    print("\n b= \n",b);

    mul(a,b,c);
    print("\n a*b= \n",c);
#endif

    return 0;
}
//---------------
