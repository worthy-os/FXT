#if !defined HAVE_DTPARANOIA_H__
#define      HAVE_DTPARANOIA_H__

// define for enabling *many* checks:
//#define  DT_PARANOIA  1


#endif // !defined HAVE_DTPARANOIA_H__
