#if !defined HAVE_HFPARANOIA_H__
#define      HAVE_HFPARANOIA_H__

// define for enabling *many* checks:
//#define  HF_PARANOIA  1


#endif // !defined HAVE_HFPARANOIA_H__
