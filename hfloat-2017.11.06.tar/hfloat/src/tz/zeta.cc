

//
// jjnote: implement using sumalt:
// zeta(s) = 1/(1-2^(1-s))*\sum_{n=1}^{\infty}{(-1)^n/n^s}
//

