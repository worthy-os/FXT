#if !defined HAVE_HFTYPES_H__
#define      HAVE_HFTYPES_H__


typedef unsigned short  LIMB;

#define MAX_LIMB 65535
#define BITS_PER_LIMB 16

typedef unsigned long   ulong;
typedef unsigned int    uint;

typedef unsigned char   uchar;


#endif // !defined HAVE_HFTYPES_H__
